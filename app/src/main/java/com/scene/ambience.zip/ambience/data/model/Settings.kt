package com.scene.ambience.data.model

enum class ThemeMode { SYSTEM, LIGHT, DARK }

enum class FocusPolicy { PAUSE, DUCK, CONTINUE }

enum class NoisyPolicy { PAUSE }
